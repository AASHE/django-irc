from rc.resources.apps.scrape.parsers.operations import *
from rc.resources.apps.scrape.parsers.education import *
from rc.resources.apps.scrape.parsers.pae import *
from rc.resources.apps.scrape.parsers.policies import *
from rc.resources.apps.scrape.parsers.programs import *
