.. AASHE Resource Center documentation master file, created by
   sphinx-quickstart on Wed Mar  7 14:55:27 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to AASHE Resource Center's documentation!
=================================================

Contents:

.. toctree::
   :maxdepth: 2

   design
   resources


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

