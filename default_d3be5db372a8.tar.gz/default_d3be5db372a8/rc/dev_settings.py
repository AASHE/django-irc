import os, sys
from settings import *


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'django_irc_dev',
        'USER': 'django_irc_dev',
        'PASSWORD': 'te86FRas',
        'HOST': '10.176.140.223',
        'PORT': '',
        }
    }
